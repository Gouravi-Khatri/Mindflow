import { GoogleGenAI, Type } from "@google/genai";
import { Message, PlannerTask, RantReframing, WisdomCardData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-2.5-flash';

const systemInstruction = `You are MindFlow, an empathetic and supportive AI mental wellness companion. Your goal is to help users navigate their feelings, find clarity, and build positive momentum. You are not a therapist, but a caring guide. Your tone should be warm, encouraging, and non-judgmental. Never give medical advice. Keep your responses concise and helpful.`;

export const getChatbotResponse = async (history: Message[], newMessage: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model,
      config: { systemInstruction },
      history: history.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }))
    });
    
    const response = await chat.sendMessage({ message: newMessage });
    return response.text;
  } catch (error) {
    console.error("Error getting chatbot response:", error);
    return "I'm sorry, I'm having a little trouble connecting right now. Please try again in a moment.";
  }
};

export const getInitialWisdom = async (): Promise<WisdomCardData[]> => {
    try {
        const prompt = "Generate 3 diverse, anonymous, and insightful wellness tips based on common mental health challenges like stress, sleep hygiene, and negative self-talk. The insights should sound like they came from a supportive community.";
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING, description: "A short, engaging title for the wisdom card." },
                            insight: { type: Type.STRING, description: "The core insight or tip, written in a compassionate tone." },
                        },
                    },
                }
            }
        });

        const wisdomArray = JSON.parse(response.text);
        return wisdomArray.map((w: any, index: number) => ({
            ...w,
            id: `wisdom-${Date.now()}-${index}`,
            likes: Math.floor(Math.random() * 50) + 10
        }));

    } catch (error) {
        console.error("Error fetching initial wisdom:", error);
        return [];
    }
};

export const synthesizeWisdom = async (userInput: string): Promise<WisdomCardData | null> => {
    try {
        const prompt = `A user shared this piece of wisdom: "${userInput}". Please synthesize this into a concise and anonymous insight for the community. Create a short title for it.`;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                         title: { type: Type.STRING, description: "A short, engaging title for the wisdom card." },
                         insight: { type: Type.STRING, description: "The synthesized insight, written in a compassionate, anonymous tone." },
                    }
                }
            }
        });
        const newWisdom = JSON.parse(response.text);
        return {
            ...newWisdom,
            id: `wisdom-${Date.now()}`,
            likes: 1,
        };

    } catch (error) {
        console.error("Error synthesizing wisdom:", error);
        return null;
    }
};


export const getNudge = async (): Promise<{ title: string; message: string }> => {
    try {
        const prompt = "Generate a single, short, kind, and proactive wellness nudge. The nudge should be encouraging and suggest a simple, actionable micro-break (like stretching, breathing, or hydrating).";
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING, description: "A short, catchy title for the nudge (e.g., '🌿 Mindful Moment')." },
                        message: { type: Type.STRING, description: "The nudge message itself." },
                    }
                }
            }
        });
        return JSON.parse(response.text);
    } catch (error) {
        console.error("Error getting nudge:", error);
        return { title: 'Wellness Check-in', message: 'Remember to be kind to yourself today.' };
    }
};

export const reframeRant = async (rantText: string): Promise<RantReframing> => {
    try {
        const prompt = `A user is venting and shared the following: "${rantText}". Your task is to first reframe their thoughts into a more compassionate and constructive perspective. Then, provide 3 simple, actionable suggestions to help them in this moment.`;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        reframe: { type: Type.STRING, description: "The reframed, compassionate perspective of the user's rant." },
                        suggestions: { 
                            type: Type.ARRAY, 
                            items: { type: Type.STRING },
                            description: "An array of 3 short, actionable suggestions."
                        },
                    }
                }
            }
        });
        return JSON.parse(response.text);
    } catch (error) {
        console.error("Error reframing rant:", error);
        return {
            reframe: "It's completely valid to feel this way. Challenges can be overwhelming, but they are also temporary. Your feelings are a sign of how much you care.",
            suggestions: ["Take three deep, slow breaths.", "Step away for 5 minutes if you can.", "Focus on one small thing you can control right now."]
        };
    }
};

export const generatePlan = async (mood: string): Promise<PlannerTask[]> => {
    try {
        const prompt = `Create a personalized daily wellness plan for a user whose current mood is "${mood}". The plan should include 6-8 tasks distributed throughout the day, aligned with typical energy rhythms (e.g., deep work during peak energy, lighter tasks during low energy). For each task, provide a time slot, a description, and a 'why it matters' reason. Assign an energy level (high, medium, or low) to each task.`;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            timeSlot: { type: Type.STRING, description: "The suggested time for the task (e.g., '9:00 AM - 11:00 AM')." },
                            task: { type: Type.STRING, description: "A short description of the task." },
                            reason: { type: Type.STRING, description: "A brief 'why it matters' explanation." },
                            energyLevel: { type: Type.STRING, description: "The required energy level: 'high', 'medium', or 'low'." },
                        }
                    }
                }
            }
        });

        const plan = JSON.parse(response.text);
        return plan.map((p: any, index: number) => ({
            ...p,
            id: `task-${Date.now()}-${index}`,
            completed: false,
            energyLevel: ['high', 'medium', 'low'].includes(p.energyLevel) ? p.energyLevel : 'medium'
        }));
    } catch (error) {
        console.error("Error generating plan:", error);
        return [];
    }
};
