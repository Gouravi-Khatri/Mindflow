import React, { useState, useCallback } from 'react';
import type { View } from './types';
import AICompanion from './components/AICompanion';
import CollectiveWisdom from './components/CollectiveWisdom';
import MomentumPlanner from './components/MomentumPlanner';
import ProactiveNudges from './components/ProactiveNudges';
import RantBooth from './components/RantBooth';
import Header from './components/common/Header';
import FeatureCard from './components/common/FeatureCard';
import { ChatIcon, WisdomIcon, NudgeIcon, RantIcon, PlannerIcon } from './components/common/Icons';
import Notification from './components/common/Notification';
import AuroraBackground from './components/AuroraBackground';


const App: React.FC = () => {
    const [view, setView] = useState<View>('main');
    const [notification, setNotification] = useState<{ title: string; message: string; show: boolean }>({
        title: '',
        message: '',
        show: false,
    });

    const showNotification = useCallback((title: string, message: string) => {
        setNotification({ title, message, show: true });
        setTimeout(() => {
            setNotification((prev) => ({ ...prev, show: false }));
        }, 5000);
    }, []);

    const renderView = () => {
        switch (view) {
            case 'chatbot':
                return <AICompanion onBack={() => setView('main')} showNotification={showNotification} />;
            case 'wisdom':
                return <CollectiveWisdom onBack={() => setView('main')} showNotification={showNotification} />;
            case 'nudges':
                return <ProactiveNudges onBack={() => setView('main')} showNotification={showNotification} />;
            case 'rant':
                return <RantBooth onBack={() => setView('main')} showNotification={showNotification} />;
            case 'planner':
                return <MomentumPlanner onBack={() => setView('main')} showNotification={showNotification} />;
            default:
                return (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
                        <FeatureCard
                            icon={<ChatIcon />}
                            title="AI Companion"
                            description="24/7 empathetic support with personalized conversations and mood tracking"
                            onClick={() => setView('chatbot')}
                        />
                        <FeatureCard
                            icon={<WisdomIcon />}
                            title="Collective Wisdom"
                            description="AI-synthesized insights from community experiences and coping strategies"
                            onClick={() => setView('wisdom')}
                        />
                        <FeatureCard
                            icon={<NudgeIcon />}
                            title="Proactive Nudges"
                            description="Smart notifications that detect mood patterns and offer timely support"
                            onClick={() => setView('nudges')}
                        />
                        <FeatureCard
                            icon={<RantIcon />}
                            title="Rant Booth"
                            description="Venting space with AI reframing for emotional release and clarity"
                            onClick={() => setView('rant')}
                        />
                        <FeatureCard
                            icon={<PlannerIcon />}
                            title="Momentum Planner"
                            description="Personalized daily planning aligned with your energy rhythms"
                            onClick={() => setView('planner')}
                        />
                         <div className="md:col-span-2 lg:col-span-1">
                            <FeatureCard
                                icon={<span className="text-3xl">💖</span>}
                                title="Support MindFlow"
                                description="Your support helps us continue our mission to make mental wellness accessible to all."
                                onClick={() => showNotification('Thank You!', 'We appreciate your support in our mission.')}
                            />
                        </div>
                    </div>
                );
        }
    };

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 font-sans">
            <AuroraBackground />
            <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
                
                @keyframes glow {
                    0%, 100% { filter: brightness(1) drop-shadow(0 0 5px rgba(167, 139, 250, 0.5)); }
                    50% { filter: brightness(1.2) drop-shadow(0 0 15px rgba(167, 139, 250, 0.7)); }
                }
                .animate-glow { animation: glow 4s ease-in-out infinite; }
            `}</style>

            <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-8 z-10">
                <Header />
                <main className="mt-10">
                    {renderView()}
                </main>
            </div>

            <Notification
                title={notification.title}
                message={notification.message}
                show={notification.show}
                onDismiss={() => setNotification((prev) => ({ ...prev, show: false }))}
            />
        </div>
    );
};

export default App;
