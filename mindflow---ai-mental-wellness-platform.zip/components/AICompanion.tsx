import React, { useState, useEffect, useRef } from 'react';
import type { Mood, Message } from '../types';
import { getChatbotResponse } from '../services/geminiService';
import BackButton from './common/BackButton';
import StatsCard from './common/StatsCard';
import { TypingIndicator } from './common/Icons';

interface AICompanionProps {
    onBack: () => void;
    showNotification: (title: string, message: string) => void;
}

const moods: { name: Mood; emoji: string }[] = [
    { name: 'happy', emoji: '😊' },
    { name: 'calm', emoji: '😌' },
    { name: 'anxious', emoji: '😰' },
    { name: 'sad', emoji: '😢' },
    { name: 'angry', emoji: '😤' },
];

const AICompanion: React.FC<AICompanionProps> = ({ onBack, showNotification }) => {
    const [messages, setMessages] = useState<Message[]>([
        { sender: 'bot', text: "Hello! I'm here to support you. How are you feeling today? You can select a mood or just start typing." }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
    const [moodStreak, setMoodStreak] = useState(3);
    const [moodHistory, setMoodHistory] = useState(['😊', '😌', '😰', '😊', '😌', '😊', '?']);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages, isLoading]);

    const handleSendMessage = async (messageText?: string) => {
        const text = (messageText || input).trim();
        if (!text || isLoading) return;

        const newUserMessage: Message = { sender: 'user', text };
        setMessages(prev => [...prev, newUserMessage]);
        setInput('');
        setIsLoading(true);

        const response = await getChatbotResponse(messages, text);

        setMessages(prev => [...prev, { sender: 'bot', text: response }]);
        setIsLoading(false);
    };

    const handleMoodSelect = (mood: Mood) => {
        if (isLoading) return;
        setSelectedMood(mood);
        const moodEmoji = moods.find(m => m.name === mood)?.emoji || '';
        
        setMoodHistory(prev => [...prev.slice(1), moodEmoji]);
        setMoodStreak(prev => prev + 1);
        showNotification('Mood Logged!', `You've logged your mood as ${mood}. Your streak is now ${moodStreak + 1} days!`);

        handleSendMessage(`I'm feeling ${mood} today.`);
    };

    return (
        <div className="animate-fadeIn">
            <BackButton onClick={onBack} />
            <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">AI Companion</h2>
            
            <StatsCard value={moodStreak.toString()} label="Day Mood Streak" />

            <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 my-6">
                {moods.map(({ name, emoji }) => (
                    <button
                        key={name}
                        onClick={() => handleMoodSelect(name)}
                        className={`p-4 rounded-2xl text-center transition-all duration-300 transform hover:scale-105 ${selectedMood === name ? 'bg-gradient-to-br from-purple-600 to-indigo-600 border-transparent shadow-lg' : 'bg-slate-800/50 border border-slate-700 hover:border-purple-500'}`}
                    >
                        <div className="text-4xl mb-2">{emoji}</div>
                        <div className="capitalize text-sm">{name}</div>
                    </button>
                ))}
            </div>

            <h4 className="text-center text-slate-400 mb-2">This Week's Mood History</h4>
            <div className="flex justify-center gap-2 mb-8">
                {moodHistory.map((emoji, index) => (
                    <div key={index} className="w-12 h-12 bg-slate-800/50 border border-slate-700 rounded-lg flex items-center justify-center text-2xl">{emoji}</div>
                ))}
            </div>

            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl shadow-2xl h-[500px] flex flex-col">
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${msg.sender === 'user' ? 'bg-gradient-to-br from-purple-600 to-indigo-700 text-white' : 'bg-slate-700'}`}>
                                <p className="text-sm break-words">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                     {isLoading && (
                        <div className="flex justify-start">
                            <div className="px-4 py-3 rounded-2xl bg-slate-700">
                                <TypingIndicator />
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <div className="p-4 border-t border-slate-700">
                    <div className="flex items-center gap-3">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Type your message..."
                            className="flex-1 bg-slate-900 border border-slate-600 rounded-xl px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
                            disabled={isLoading}
                        />
                        <button onClick={() => handleSendMessage()} disabled={isLoading || !input} className="px-6 py-2 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white font-semibold transition transform hover:scale-105 disabled:opacity-50 disabled:scale-100">
                            Send
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AICompanion;
