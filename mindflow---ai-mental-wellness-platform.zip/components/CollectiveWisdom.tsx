import React, { useState, useEffect, useCallback } from 'react';
import type { WisdomCardData } from '../types';
import { getInitialWisdom, synthesizeWisdom } from '../services/geminiService';
import BackButton from './common/BackButton';
import StatsCard from './common/StatsCard';
import { HeartIcon, PlusIcon, LoadingIcon } from './common/Icons';

interface CollectiveWisdomProps {
    onBack: () => void;
    showNotification: (title: string, message: string) => void;
}

const WisdomCard: React.FC<{ card: WisdomCardData, onLike: (id: string) => void }> = ({ card, onLike }) => {
    return (
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6 relative overflow-hidden transition-transform transform hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-900/50">
            <h3 className="text-xl font-bold text-purple-400 mb-3">{card.title}</h3>
            <p className="text-slate-300 leading-relaxed">{card.insight}</p>
            <div className="mt-4 flex items-center text-slate-400">
                <button onClick={() => onLike(card.id)} className="flex items-center gap-2 hover:text-pink-400 transition-colors">
                    <HeartIcon />
                    <span>{card.likes}</span>
                </button>
            </div>
             <div className="absolute top-4 right-4 text-2xl opacity-30">✨</div>
        </div>
    );
};

const CollectiveWisdom: React.FC<CollectiveWisdomProps> = ({ onBack, showNotification }) => {
    const [wisdomCards, setWisdomCards] = useState<WisdomCardData[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchWisdom = useCallback(async () => {
        setIsLoading(true);
        const cards = await getInitialWisdom();
        setWisdomCards(cards);
        setIsLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        fetchWisdom();
    }, [fetchWisdom]);
    
    const handleLike = (id: string) => {
        setWisdomCards(cards => cards.map(card => card.id === id ? { ...card, likes: card.likes + 1 } : card));
    };

    const handleAddWisdom = async () => {
        const userInput = prompt("Share your wellness wisdom with the community:");
        if (userInput && userInput.trim()) {
            setIsSubmitting(true);
            const newWisdom = await synthesizeWisdom(userInput);
            if (newWisdom) {
                setWisdomCards(prev => [newWisdom, ...prev]);
                showNotification('Wisdom Shared!', 'Your insight has been added to the community circle.');
            } else {
                showNotification('Error', 'Could not process your wisdom. Please try again.');
            }
            setIsSubmitting(false);
        }
    };
    
    return (
        <div className="animate-fadeIn">
            <BackButton onClick={onBack} />
            <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">Collective Wisdom</h2>
            <StatsCard value={wisdomCards.length.toString()} label="Community Insights" />

            <div className="text-center my-8">
                <button 
                    onClick={handleAddWisdom} 
                    disabled={isSubmitting}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white font-semibold transition transform hover:scale-105 disabled:opacity-50 disabled:scale-100"
                >
                    {isSubmitting ? <LoadingIcon/> : <PlusIcon />}
                    Share Your Wisdom
                </button>
            </div>
            
            {isLoading ? (
                <div className="flex justify-center items-center h-64">
                    <LoadingIcon />
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {wisdomCards.map(card => <WisdomCard key={card.id} card={card} onLike={handleLike} />)}
                </div>
            )}
        </div>
    );
};

export default CollectiveWisdom;
