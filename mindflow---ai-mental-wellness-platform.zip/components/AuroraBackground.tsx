import React from 'react';

const AuroraBackground: React.FC = () => {
  return (
    <>
      <style>{`
        @keyframes aurora {
            0%, 100% { transform: translate(-50%, -50%) rotate(0deg) scale(1.2); opacity: 0.2; }
            33% { transform: translate(-30%, -60%) rotate(120deg) scale(1.5); opacity: 0.3; }
            66% { transform: translate(-70%, -40%) rotate(240deg) scale(1.0); opacity: 0.25; }
        }
      `}</style>
      <div className="fixed top-0 left-0 w-full h-full -z-10 overflow-hidden">
        <div 
          className="absolute top-1/2 left-1/2 w-[200%] h-[200%] bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(107,70,193,1)_50%,transparent_100%)]"
          style={{ animation: 'aurora 20s ease-in-out infinite' }}
        />
        <div 
          className="absolute top-1/2 left-1/2 w-[200%] h-[200%] bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(236,72,153,1)_50%,transparent_100%)]"
          style={{ animation: 'aurora 25s ease-in-out infinite reverse', animationDelay: '-5s' }}
        />
      </div>
    </>
  );
};

export default AuroraBackground;
