import React, { useState } from 'react';
import type { RantReframing } from '../types';
import { reframeRant } from '../services/geminiService';
import BackButton from './common/BackButton';
import StatsCard from './common/StatsCard';
import { LoadingIcon, RantIcon } from './common/Icons';

interface RantBoothProps {
    onBack: () => void;
    showNotification: (title: string, message: string) => void;
}

const RantBooth: React.FC<RantBoothProps> = ({ onBack, showNotification }) => {
    const [rantText, setRantText] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [reframing, setReframing] = useState<RantReframing | null>(null);
    const [rantSessions, setRantSessions] = useState(5);

    const handleProcessRant = async () => {
        if (!rantText.trim() || isProcessing) return;
        
        setIsProcessing(true);
        setReframing(null);
        
        const result = await reframeRant(rantText);
        setReframing(result);
        
        setRantSessions(prev => prev + 1);
        showNotification('Thoughts Reframed!', 'Your venting session has been processed with care and understanding.');
        setIsProcessing(false);
    };

    return (
        <div className="animate-fadeIn">
            <BackButton onClick={onBack} />
            <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">Rant Booth</h2>
            <StatsCard value={rantSessions.toString()} label="Venting Sessions This Month" />

            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-8 my-8 text-center">
                <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-pink-500 to-red-500 flex items-center justify-center mb-4 shadow-lg shadow-pink-500/30">
                    <RantIcon size={48} />
                </div>
                <p className="text-slate-400 mb-4">A safe space to vent. Type your thoughts, and let AI help you find a new perspective.</p>
                <textarea
                    value={rantText}
                    onChange={(e) => setRantText(e.target.value)}
                    placeholder="What's on your mind? Let it all out..."
                    rows={5}
                    className="w-full bg-slate-900 border border-slate-600 rounded-xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-pink-500 transition mb-4"
                    disabled={isProcessing}
                />
                <button
                    onClick={handleProcessRant}
                    disabled={isProcessing || !rantText.trim()}
                    className="px-8 py-3 rounded-xl bg-gradient-to-br from-pink-600 to-red-600 text-white font-semibold transition transform hover:scale-105 disabled:opacity-50 disabled:scale-100"
                >
                    {isProcessing ? <div className="flex items-center gap-2"> <LoadingIcon/> Processing... </div> : 'Reframe My Thoughts'}
                </button>
            </div>
            
            {isProcessing && (
                <div className="text-center">
                    <LoadingIcon />
                    <p className="mt-2 text-slate-400">Finding a new perspective for you...</p>
                </div>
            )}

            {reframing && (
                <div className="space-y-6 animate-fadeIn">
                    <h3 className="text-2xl font-bold text-center">Your Reframed Perspective</h3>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                        <h4 className="text-lg font-semibold text-pink-400 mb-2">What You Said:</h4>
                        <p className="italic text-slate-400">"{rantText}"</p>
                    </div>
                     <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                        <h4 className="text-lg font-semibold text-emerald-400 mb-2">A Kinder Perspective:</h4>
                        <p className="text-slate-200">{reframing.reframe}</p>
                    </div>
                     <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                        <h4 className="text-lg font-semibold text-purple-400 mb-2">Actionable Suggestions:</h4>
                        <ul className="list-disc list-inside space-y-2 text-slate-200">
                            {reframing.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                        </ul>
                    </div>
                </div>
            )}
        </div>
    );
};

export default RantBooth;
