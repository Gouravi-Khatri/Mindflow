import React, { useState } from 'react';
import { getNudge } from '../services/geminiService';
import BackButton from './common/BackButton';
import StatsCard from './common/StatsCard';
import { LoadingIcon } from './common/Icons';

interface ProactiveNudgesProps {
    onBack: () => void;
    showNotification: (title: string, message: string) => void;
}

const ProactiveNudges: React.FC<ProactiveNudgesProps> = ({ onBack, showNotification }) => {
    const [isSimulating, setIsSimulating] = useState(false);
    const [nudgeHistory, setNudgeHistory] = useState([
        { time: 'Yesterday, 3:00 PM', task: 'Remember that breathing exercise we practiced?', reason: 'Triggered by: Mood pattern analysis' },
        { time: '2 Days Ago, 10:00 AM', task: 'Your mood has been improving - amazing progress!', reason: 'Triggered by: Positive mood trend' }
    ]);
    
    const handleSimulateNudge = async () => {
        setIsSimulating(true);
        const nudge = await getNudge();
        showNotification(nudge.title, nudge.message);

        const newHistoryItem = {
            time: 'Just now',
            task: nudge.message,
            reason: 'Triggered by: AI simulation'
        };
        setNudgeHistory(prev => [newHistoryItem, ...prev].slice(0, 5));
        
        setIsSimulating(false);
    };

    return (
        <div className="animate-fadeIn">
            <BackButton onClick={onBack} />
            <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">Proactive Nudges</h2>
            <StatsCard value="7" label="Days of Active Nudges" />

            <div className="text-center bg-slate-800/50 border border-slate-700 rounded-2xl p-8 my-8">
                <p className="text-slate-400 mb-4">AI can detect mood patterns and send personalized support messages.</p>
                <button
                    onClick={handleSimulateNudge}
                    disabled={isSimulating}
                    className="px-6 py-3 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white font-semibold transition transform hover:scale-105 disabled:opacity-50 disabled:scale-100"
                >
                    {isSimulating ? <div className="flex items-center gap-2"> <LoadingIcon/> Simulating... </div> : 'Simulate a Nudge'}
                </button>
            </div>
            
            <div>
                <h3 className="text-xl font-bold mb-4">Recent Nudge History</h3>
                <div className="space-y-4">
                    {nudgeHistory.map((item, index) => (
                        <div key={index} className="bg-slate-800/50 p-4 rounded-lg border-l-4 border-purple-500">
                            <div className="font-bold text-sm text-purple-300 mb-1">{item.time}</div>
                            <div className="text-slate-200">{item.task}</div>
                            <div className="text-xs italic text-slate-500 mt-2">{item.reason}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ProactiveNudges;
