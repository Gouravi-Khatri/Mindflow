import React, { useState, useEffect, useCallback } from 'react';
import type { PlannerTask } from '../types';
import { generatePlan } from '../services/geminiService';
import BackButton from './common/BackButton';
import StatsCard from './common/StatsCard';
import { LoadingIcon } from './common/Icons';

interface MomentumPlannerProps {
    onBack: () => void;
    showNotification: (title: string, message: string) => void;
}

const energyStyles = {
    high: 'border-l-emerald-400',
    medium: 'border-l-purple-400',
    low: 'border-l-pink-400'
};

const TaskItem: React.FC<{ task: PlannerTask, onToggle: (id: string) => void }> = ({ task, onToggle }) => {
    return (
        <div
            onClick={() => onToggle(task.id)}
            className={`p-4 rounded-xl border-l-4 transition-all duration-300 cursor-pointer ${energyStyles[task.energyLevel]} ${task.completed ? 'bg-emerald-500/10 border-emerald-400' : 'bg-slate-800/50 hover:bg-slate-700/50'}`}
        >
            <div className={`font-bold mb-1 ${task.completed ? 'line-through text-slate-500' : 'text-purple-300'}`}>
                {task.timeSlot} {task.completed && '✅'}
            </div>
            <p className={`font-semibold ${task.completed ? 'line-through text-slate-400' : 'text-slate-100'}`}>{task.task}</p>
            <p className={`text-xs italic mt-2 ${task.completed ? 'text-slate-500' : 'text-slate-400'}`}>
                Why it matters: {task.reason}
            </p>
        </div>
    );
}

const MomentumPlanner: React.FC<MomentumPlannerProps> = ({ onBack, showNotification }) => {
    const [tasks, setTasks] = useState<PlannerTask[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentMood, setCurrentMood] = useState('neutral');

    const fetchPlan = useCallback(async (mood: string) => {
        setIsLoading(true);
        const plan = await generatePlan(mood);
        setTasks(plan);
        setIsLoading(false);
        if (plan.length > 0) {
            showNotification('New Plan Ready!', `Your schedule has been optimized for a ${mood} mood.`);
        } else {
            showNotification('Error', 'Could not generate a plan. Please try again.');
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        fetchPlan(currentMood);
    }, [fetchPlan, currentMood]);

    const handleToggleTask = (id: string) => {
        setTasks(prevTasks =>
            prevTasks.map(task => {
                if (task.id === id) {
                    if (!task.completed) {
                        showNotification('Task Completed!', `Great job on: "${task.task}"`);
                    }
                    return { ...task, completed: !task.completed };
                }
                return task;
            })
        );
    };

    const completedTasks = tasks.filter(t => t.completed).length;
    const totalTasks = tasks.length;

    return (
        <div className="animate-fadeIn">
            <BackButton onClick={onBack} />
            <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">Momentum Planner</h2>
            <StatsCard value={`${completedTasks}/${totalTasks}`} label="Tasks Completed Today" />

            <div className="text-center my-8">
                 <p className="text-slate-400 mb-2">How are you feeling now? Regenerate plan based on:</p>
                <div className="flex justify-center gap-2">
                    <button onClick={() => setCurrentMood('motivated')} className="px-4 py-2 text-sm rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/40 transition">Motivated</button>
                    <button onClick={() => setCurrentMood('tired')} className="px-4 py-2 text-sm rounded-lg bg-pink-500/20 text-pink-300 hover:bg-pink-500/40 transition">Tired</button>
                    <button onClick={() => setCurrentMood('stressed')} className="px-4 py-2 text-sm rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/40 transition">Stressed</button>
                </div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center h-64">
                    <LoadingIcon />
                </div>
            ) : (
                <div className="space-y-4">
                    {tasks.length > 0 ? (
                        tasks.map(task => <TaskItem key={task.id} task={task} onToggle={handleToggleTask} />)
                    ) : (
                        <p className="text-center text-slate-400">Could not generate a plan. Try regenerating.</p>
                    )}
                </div>
            )}
        </div>
    );
};

export default MomentumPlanner;
