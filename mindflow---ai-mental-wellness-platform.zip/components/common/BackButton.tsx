import React from 'react';

interface BackButtonProps {
    onClick: () => void;
}

const BackButton: React.FC<BackButtonProps> = ({ onClick }) => {
    return (
        <button
            onClick={onClick}
            className="mb-6 px-4 py-2 rounded-lg border border-purple-500 text-purple-400 font-semibold transition-colors hover:bg-purple-500 hover:text-white"
        >
            ← Back to Features
        </button>
    );
};

export default BackButton;
