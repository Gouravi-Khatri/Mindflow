import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="text-center py-6">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 text-transparent bg-clip-text mb-2 animate-glow">
                🧠 MindFlow
            </h1>
            <p className="text-slate-400 text-lg">
                Your AI-Powered Mental Wellness Companion
            </p>
        </header>
    );
};

export default Header;
