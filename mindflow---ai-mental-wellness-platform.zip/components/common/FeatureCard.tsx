import React from 'react';

interface FeatureCardProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    onClick: () => void;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, onClick }) => {
    return (
        <div
            onClick={onClick}
            className="group bg-slate-800/50 border border-slate-700 rounded-2xl p-6 text-center cursor-pointer transition-all duration-300 ease-in-out hover:-translate-y-2 hover:shadow-2xl hover:shadow-purple-900/50 relative overflow-hidden"
        >
            <div className="absolute top-0 left-0 h-1 w-full bg-gradient-to-r from-purple-500 to-indigo-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-in-out origin-left"></div>
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-indigo-700 rounded-xl flex items-center justify-center mx-auto mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                {icon}
            </div>
            <h2 className="text-2xl font-bold mb-2 text-slate-100">{title}</h2>
            <p className="text-slate-400 leading-relaxed">{description}</p>
        </div>
    );
};

export default FeatureCard;
