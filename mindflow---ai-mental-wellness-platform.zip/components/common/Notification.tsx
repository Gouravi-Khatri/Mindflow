import React from 'react';

interface NotificationProps {
    title: string;
    message: string;
    show: boolean;
    onDismiss: () => void;
}

const Notification: React.FC<NotificationProps> = ({ title, message, show, onDismiss }) => {
    return (
        <div
            className={`fixed top-5 right-5 w-80 max-w-[90vw] bg-gradient-to-br from-cyan-400 to-blue-500 text-white rounded-xl shadow-2xl p-5 transform transition-all duration-500 ease-in-out z-50 ${
                show ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
            }`}
        >
            <h3 className="font-bold text-lg mb-1">{title}</h3>
            <p className="text-sm text-blue-100">{message}</p>
            <button onClick={onDismiss} className="absolute top-2 right-3 text-white/70 hover:text-white">&times;</button>
        </div>
    );
};

export default Notification;
