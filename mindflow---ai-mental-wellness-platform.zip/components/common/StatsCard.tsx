import React from 'react';

interface StatsCardProps {
    value: string;
    label: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ value, label }) => {
    return (
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 text-center">
            <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
                {value}
            </div>
            <div className="text-sm text-slate-400 mt-1">{label}</div>
        </div>
    );
};

export default StatsCard;
