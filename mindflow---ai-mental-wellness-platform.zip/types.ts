export type Mood = 'happy' | 'calm' | 'anxious' | 'sad' | 'angry';
export type View = 'main' | 'chatbot' | 'wisdom' | 'nudges' | 'rant' | 'planner';

export interface Message {
  sender: 'user' | 'bot';
  text: string;
}

export interface WisdomCardData {
  id: string;
  title: string;
  insight: string;
  likes: number;
}

export interface PlannerTask {
  id: string;
  timeSlot: string;
  task: string;
  reason: string;
  energyLevel: 'high' | 'medium' | 'low';
  completed: boolean;
}

export interface RantReframing {
    reframe: string;
    suggestions: string[];
}
